import React from "react";

export default function StudyConsultancySection() {
  return (
    <div className="container bg-white py-10 px-12 flex flex-col lg:flex-row justify-between items-start gap-10">
      {/* Left Section */}
      <div className="w-full lg:w-1/2">
        <h2 className="text-3xl font-bold leading-snug text-gray-900">
          Not just a <span className="text-blue-600">traditional</span> study<br />
          abroad <span className="text-blue-600">consultancy</span>
        </h2>

        <p className="mt-5 text-gray-700 leading-relaxed">
          EasyLearn Educare is a trusted educational consultancy in Kolkata,
          guiding students toward top MBA and professional colleges across
          India. We provide expert counselling, admission assistance, and career
          guidance to help students achieve their academic and professional
          dreams.
        </p>

        <p className="mt-4 text-gray-700 leading-relaxed">
          EasyLearn Educare is a trusted educational consultancy in Kolkata,
          guiding students toward top MBA and professional colleges across
          India. We provide expert counselling, admission assistance, and career
          guidance to help students achieve their academic and professional
          dreams.
        </p>
      </div>

      {/* Right Form Section */}
      <div className="w-full lg:w-1/2">
        <div className="w-full max-w-md ml-auto bg-white border rounded-xl shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 text-center">
            Book Your <span className="text-blue-600">FREE Consultation</span> Call
            with Our Certified Counsellors
          </h3>

          <form className="mt-6 space-y-4">
            <input
              type="text"
              placeholder="Full Name *"
              className="w-full border rounded-md p-3 focus:outline-blue-500"
            />

            <input
              type="text"
              placeholder="Mobile Number *"
              className="w-full border rounded-md p-3 focus:outline-blue-500"
            />

            <input
              type="email"
              placeholder="Email ID *"
              className="w-full border rounded-md p-3 focus:outline-blue-500"
            />

            <select className="w-full border rounded-md p-3 focus:outline-blue-500">
              <option>Destination *</option>
              <option>USA</option>
              <option>UK</option>
              <option>Canada</option>
              <option>Australia</option>
              <option>Germany</option>
            </select>

            <label className="flex items-start gap-2 text-sm text-gray-700">
              <input type="checkbox" />
              <span>
                I agree to AECC's <span className="text-blue-600">Privacy Policy</span> and
                <span className="text-blue-600"> Terms and Conditions</span> *
              </span>
            </label>

            <button
              type="submit"
              className="w-full bg-green-500 text-white font-semibold py-3 rounded-md hover:bg-green-600 transition"
            >
              Book a FREE Consultation →
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
