import React from "react";

export default function CountriesAndWhyChoose() {
  const countries = [
    { src: "https://flagcdn.com/gb.svg", name: "UK" },
    { src: "https://flagcdn.com/us.svg", name: "USA" },
    { src: "https://flagcdn.com/au.svg", name: "Australia" },
    { src: "https://flagcdn.com/ca.svg", name: "Canada" },
    { src: "https://flagcdn.com/ie.svg", name: "Ireland" },
    { src: "https://flagcdn.com/eu.svg", name: "Europe" },
    { src: "https://flagcdn.com/sg.svg", name: "Singapore" },
    { src: "https://flagcdn.com/ae.svg", name: "UAE" },
    { src: "https://flagcdn.com/nz.svg", name: "New Zealand" },
  ];

  const features = [
    {
      title: "Flexibility",
      desc: "We provide expert counselling, admission assistance, and career guidance.",
    },
    {
      title: "Quality",
      desc: "We ensure high‑quality services for students aspiring to study abroad.",
    },
    {
      title: "Experienced",
      desc: "Our experienced counsellors guide you throughout your academic journey.",
    },
    {
      title: "Global",
      desc: "We assist students aiming for top universities across the globe.",
    },
  ];

  return (
    <div className="w-full">
      {/* Countries Section */}
      <div className="bg-[#052a4f] text-white py-10 px-6 text-center">
        <h2 className="text-3xl font-bold mb-8">Countries For Study Abroad</h2>

        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-6 justify-center max-w-5xl mx-auto mb-6">
          {countries.map((c, idx) => (
            <img
              key={idx}
              src={c.src}
              alt={c.name}
              className="w-20 h-14 object-cover rounded shadow border"
            />
          ))}
        </div>

        <button className="mt-4 px-6 py-2 bg-white text-[#052a4f] font-semibold rounded-full shadow hover:bg-gray-200 transition">
          View More 
        </button>
      </div>

      {/* Why Choose Section */}
      <div className="conatiner bg-white py-12 px-12 text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Why Choose <span className="text-blue-600">Easylearn Educare</span>?
        </h2>

        <p className="text-gray-700 max-w-3xl mx-auto leading-relaxed mb-10">
          We provide expert counselling, admission assistance, and career guidance to help students
          achieve their academic and professional dreams. Our dedicated team ensures high‑quality
          service and trusted mentorship.
        </p>

        <div className=" grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {features.map((f, idx) => (
            <div
              key={idx}
              className="border-2 border-blue-400 rounded-xl p-6 shadow hover:shadow-lg transition bg-white"
            >
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{f.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
