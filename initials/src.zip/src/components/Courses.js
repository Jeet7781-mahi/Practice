import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Autoplay } from "swiper/modules";
import box from "../Images/graduate-guy-graduation-gown-with-diploma-his-hands-campus.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faGraduationCap } from "@fortawesome/free-solid-svg-icons";

import "swiper/css";
import "swiper/css/navigation";

export default function CoursesCarousel() {
  const courses = [
    { id: 1, title: "B-Tech", desc: "We provide expert counselling, admission assistance, and career guidance." },
    { id: 2, title: "MBA", desc: "We provide expert counselling, admission assistance, and career guidance." },
    { id: 3, title: "M-Tech", desc: "We provide expert counselling, admission assistance, and career guidance." },
    { id: 4, title: "BBA", desc: "We provide expert counselling, admission assistance, and career guidance." },
  ];

  return (
    <section className="container py-14 bg-white relative">
      <div className=" px-5 text-center">

        {/* Heading */}
        <div className="flex items-center justify-center gap-3 mb-10">
          <FontAwesomeIcon icon={faGraduationCap} className="h-10 w-10 text-indigo-600" />
          <h2 className="text-3xl md:text-4xl font-bold">
            Domestic <span className="text-indigo-600">Online</span> Courses
          </h2>
        </div>

        {/* OUTSIDE ARROWS */}
        <button
          className="course-prev hidden md:flex items-center justify-center absolute  top-1/2 -translate-y-1/2 w-12 h-12 bg-white border shadow-md rounded-full text-gray-600 text-2xl hover:text-black hover:shadow-lg transition z-20"
        >
          ❮
        </button>

        <button
          className="course-next hidden md:flex items-center justify-center absolute right-16 top-1/2 -translate-y-1/2 w-12 h-12 bg-white border shadow-md rounded-full text-gray-600 text-2xl hover:text-black hover:shadow-lg transition z-20"
        >
          ❯
        </button>

        {/* Slider */}
        <div className="px-16">
          <Swiper
            modules={[Navigation, Autoplay]}
            autoplay={{ delay: 2600 }}
            loop={true}
            navigation={{
              nextEl: ".course-next",
              prevEl: ".course-prev",
            }}
            spaceBetween={30}
            slidesPerView={3}
            breakpoints={{
              320: { slidesPerView: 1 },
              640: { slidesPerView: 2 },
              1024: { slidesPerView: 3 },
            }}
            className="pb-6"
          >
            {courses.map((course) => (
              <SwiperSlide key={course.id}>
                <div
                  className="relative h-56 rounded-xl overflow-hidden shadow-lg bg-cover bg-center group cursor-pointer transition-transform duration-500"
                  style={{ backgroundImage: `url(${box})` }}
                >
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-black/50 group-hover:bg-black/60 transition"></div>

                  {/* Text */}
                  <div className="absolute inset-0 flex flex-col justify-center items-center text-white px-6 text-center">
                    <h3 className="text-2xl font-semibold mb-2 group-hover:scale-105 transition">
                      {course.title}
                    </h3>
                    <p className="text-sm opacity-90">{course.desc}</p>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>

      </div>
    </section>
  );
}
