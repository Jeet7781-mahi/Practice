import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import mainLogo from "../Images/logo.png";
import { faPhone, faEnvelope, faLocationDot } from "@fortawesome/free-solid-svg-icons";
import { faFacebookF, faTwitter, faLinkedinIn } from "@fortawesome/free-brands-svg-icons";

const Footer = () => {
  return (
    <footer className="bg-[#2d2d2d] text-white px-6 py-10 md:px-20">
        <div className="p-2"></div>
      <div className="grid md:grid-cols-2 gap-10">

        {/* LEFT SECTION */}
        <div>
          {/* Logo Placeholder */}
          <div className=" mb-4"><img src={mainLogo} alt="Easy Learn" srcset="" className="h-32 object-contain"  /></div>
            <p className="flex items-center gap-2 text-sm mb-4">Learn Smarter, Dream Bigger with EasyLearn Educare. Empowering students with expert study abroad guidance & digital learning. You are next!</p>
          <p className="flex items-center gap-2 text-sm">
            <FontAwesomeIcon icon={faPhone} /> 8240409187
          </p>
          <p className="flex items-center gap-2 text-sm mt-2">
            <FontAwesomeIcon icon={faEnvelope} /> ask@easylearne.com
          </p>
         {/* Social Icons */}
          <div className="flex gap-4 mt-2 text-xl">
            <a href="#"><FontAwesomeIcon icon={faFacebookF} className="cursor-pointer hover:text-blue-400" /></a>
            <a href="#"><FontAwesomeIcon icon={faTwitter} className="cursor-pointer hover:text-blue-400" /></a>
            <a href="#"><FontAwesomeIcon icon={faLinkedinIn} className="cursor-pointer hover:text-blue-400" /></a>
          </div>
        </div>

        {/* NEWSLETTER */}
        <div className="md:col-span-1">
            <div className=""></div>
          <h3 className="font-semibold mb-3">Subscribe to Our Newsletter</h3>

          <div className="flex">
            <input
              type="email"
              placeholder="Email Address"
              className="p-2 rounded-l-md flex-grow text-black outline-none"
            />
            <button className="bg-orange-400 px-4 py-2 rounded-r-md font-semibold hover:bg-orange-500">
              SUBSCRIBE
            </button>
          </div>
          {/* QUICK LINKS */}
          <div className="grid md:grid-cols-3 gap-10 mt-10">
                <div>
                <h3 className="font-semibold mb-3">Quick Links</h3>
                <ul className="text-sm space-y-2">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">Contact us</a></li>
                    <li><a href="#">FAQ’s</a></li>
                </ul>
                </div>

                {/* USEFUL LINKS */}
                <div>
                <h3 className="font-semibold mb-3">Useful Links</h3>
                <ul className="text-sm space-y-2">
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Disclaimer</a></li>
                    <li><a href="#">Support</a></li>
                    <li><a href="#">Help Center</a></li>
                </ul>
                </div>
                <div>
                <h3 className="font-semibold mb-3">Office</h3>
                <ul className="text-sm space-y-2">
                    <p> 10 AM - 6:30 PM , Monday - Saturday</p>
                   <p><b>Kolkata Office :</b> 264, Durgapur colony, Bankim Mukherjee Road, New Alipur, Kolkata-53</p>
                    <p><b>Noida Office :</b> Office no 1026, 10th Floor. Supertech E-Square Sec 96, Noida. UP</p>
                </ul>
                </div>
        </div>
        </div>

        
      </div>

      {/* WORKING HOURS SECTION */}
      <div className="mt-10 border-t border-gray-600 pt-4  text-sm">
        <p>Copyright © 2025 Easylearn Educare. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
