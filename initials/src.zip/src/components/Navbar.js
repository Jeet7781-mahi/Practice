import React from "react";
import mainLogo from "../Images/WhatsApp Image 2025-11-30 at 9.59.06 PM.jpeg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {  faEnvelope, faPhone} from "@fortawesome/free-solid-svg-icons";
import {
  faInstagram,
  faLinkedin,
  faFacebook
} from "@fortawesome/free-brands-svg-icons";

const Header = () => {
  return (
    <>
      {/* Top Social Bar */}
      <div className="top-bar">
        <div className="social-icons text-xl">
          <FontAwesomeIcon icon={faInstagram} />
          <FontAwesomeIcon icon={faLinkedin} />
          <FontAwesomeIcon icon={faFacebook} />
        </div>
        <div className="blog-link">Our Blogs</div>
      </div>

      {/* Main Header Section */}
      <div className="main-header">
        <img
          src={mainLogo}
          alt="EasyLearn"
          className="logo"
        />

        <div className="contact-info">
          <span>
            <FontAwesomeIcon icon={faEnvelope} /> easylearneducare@gmail.com
          </span>
          <span>
            <FontAwesomeIcon icon={faPhone} /> +91 8240409187
          </span>
          <button className="enroll-btn">Enroll Now</button>
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className="navbar text-white">
        <a href="#">Home</a>
        <a href="#">About Us</a>
        <a href="#">Study Abroad</a>
        <a href="#">UG & PG Course</a>
        <a href="#">Career Guidance & Counselling</a>
        <a href="#">Contact</a>
      </nav>
    </>
  );
};

export default Header;
