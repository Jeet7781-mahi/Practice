import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, EffectFade } from "swiper/modules";
import banner1 from "../Images/banner1.jpeg";
import banner2 from "../Images/banner2.jpg";
import banner3 from "../Images/banner3.jpeg";

import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/effect-fade";

// New component for the three stat boxes
const StatBoxes = () => {
  const stats = [
    { count: "250+", label: "BEST INSTRUCTORS" },
    { count: "2,000+", label: "COURSES" },
    { count: "10,000+", label: "STUDENTS" },
  ];

  return (
    <div className="flex flex-col space-y-4">
      {stats.map((stat, index) => (
        <div
          key={index}
          className="bg-blue-700 text-white p-3 rounded-lg shadow-xl w-60 text-center transition duration-300 hover:bg-blue-800"
        >
          <p className="text-2xl font-bold mb-1">{stat.count}</p>
          <p className="text-sm font-medium tracking-wider">{stat.label}</p>
        </div>
      ))}
    </div>
  );
};

export default function Hero() {
  const slides = [
    {
      id: 1,
      bg: banner1,
      showText: true,
      align: "left", // Text is on the left
      title: (
        <p className="text-black font-bold">
          Transform Your <span className="text-blue-400">Future With</span> Expert-Led Courses
        </p>
      ),
      subtitle:
        "EasyLearn Educare is a trusted educational consultancy in Kolkata, guiding students toward top MBA and professional",
      buttons: [
        { label: "Start Now", href: "#courses", primary: true },
        { label: "Study Abroad", href: "#contact", primary: false }
      ],
      // New property to indicate this slide should show the boxes
      showBoxes: true, 
    },
    {
      id: 2,
      bg: banner2,
      align: "center",
      showText: false,
      showBoxes: false, 
    },
    {
      id: 3,
      bg: banner3,
      align: "right",
      showText: false,
      showBoxes: false, 
    },
  ];

  return (
    <section className="relative w-full h-[500px] overflow-hidden">
      <Swiper
        modules={[Autoplay, Pagination, EffectFade]}
        autoplay={{ delay: 100000 }}
        pagination={{ clickable: true }}
        effect="fade"
        loop
        className="absolute inset-0 w-full h-full"
      >
        {slides.map((slide) => (
          <SwiperSlide key={slide.id}>
            {/* Background */}
            <div
              className="w-full h-full bg-cover bg-center"
              style={{ backgroundImage: `url(${slide.bg})` }}
            ></div>

            {/* Dark overlay */}
            {/* You might need a slightly darker overlay or specific text colors 
                to make the text and boxes readable over the background image. 
                I've removed the inset-0 class on the overlay to let the content sit directly on the background. 
                For banner1, you might need to adjust text color to black or white based on the image's contrast. 
            */}
            <div className="absolute inset-0 bg-white bg-opacity-10"></div> 

            {/* Text and Boxes Content Container */}
            <div
              className="absolute inset-0 flex items-center px-6 sm:px-20"
            >
              {/* This inner div now handles the two-column layout: Text on Left, Boxes on Right */}
              <div className="w-full h-full flex items-center justify-between">
                
                {/* 1. Left Section (Text Content) */}
                {slide.showText && (
                  // I've set text-black here based on your image, adjust as needed for contrast
                  <div className="text-black max-w-2xl p-6"> 
                    <h1 className="text-5xl font-bold leading-tight">
                      {slide.title}
                    </h1>

                    {slide.subtitle && (
                      <p className="mt-4 text-lg text-black">{slide.subtitle}</p>
                    )}

                    <div className="mt-6 flex gap-4">
                      {/* Using the default button styles */}
                      <button className="bg-blue-600 px-5 py-3 rounded-md text-white hover:bg-blue-700 transition">
                        Start Journey
                      </button>
                      <button className="border border-black px-5 py-3 rounded-md text-black hover:bg-gray-200 transition">
                        Study Abroad
                      </button>
                    </div>
                  </div>
                )}
                
                {/* 2. Right Section (Stat Boxes) */}
                {/* Check if the current slide is the first one (or has showBoxes set to true) */}
                {slide.showBoxes && (
                    <div className="hidden lg:flex items-center h-full mr-20"> {/* Only show on large screens */}
                        <StatBoxes />
                    </div>
                )}
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
}